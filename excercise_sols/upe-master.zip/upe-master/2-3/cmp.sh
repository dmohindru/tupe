#!/bin/sh
time ./du.sh > /dev/null
time ./find.sh > /dev/null
