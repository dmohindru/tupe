/*
 * Readability of C is better than assembler.
 * Also, C is enough fast in modern systems.
 */
